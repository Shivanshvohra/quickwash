const PDFDocument = require("pdfkit");
const fs = require("fs");
const path = require("path");

const Order = require("../models/index").Order;

async function generateAndSaveReceipt(receiptData) {

    return new Promise((resolve, reject) => {

        try {

            const doc = new PDFDocument({
                margin: 40,
                size: "A4"
            });

            const fileName =
                `${Date.now()}-receipt_${receiptData.orderId}.pdf`;

            const uploadDir = path.join(
                __dirname,
                "..",
                "..",
                "uploads"
            );

            if (!fs.existsSync(uploadDir)) {
                fs.mkdirSync(uploadDir, {
                    recursive: true
                });
            }

            const filePath =
                path.join(uploadDir, fileName);

            const stream =
                fs.createWriteStream(filePath);

            doc.pipe(stream);

            // =====================================================
            // HELPERS
            // =====================================================

            const pageWidth =
                doc.page.width - 80;

            const startX = 40;

            const drawLine = () => {
                doc.moveTo(40, doc.y)
                    .lineTo(doc.page.width - 40, doc.y)
                    .strokeColor("#cccccc")
                    .stroke();
            };

            const drawBox = (height = 25) => {

                const y = doc.y;

                doc.rect(
                    40,
                    y,
                    pageWidth,
                    height
                ).stroke("#dddddd");

                return y;
            };

            // =====================================================
            // HEADER
            // =====================================================

            doc
                .fontSize(22)
                .font("Helvetica-Bold")
                .text("WASHEX", {
                    align: "center"
                });

            doc.moveDown(0.5);

            doc
                .fontSize(11)
                .font("Helvetica")
                .text(
                    `Receipt Generated: ${new Date().toLocaleString()}`,
                    {
                        align: "center"
                    }
                );

            doc.moveDown(1);

            drawLine();

            doc.moveDown(1);

            // =====================================================
            // ORDER INFO
            // =====================================================

            doc.font("Helvetica-Bold")
                .fontSize(13)
                .text("Order Details");

            doc.moveDown(0.5);

            const orderBoxY = drawBox(95);

            doc
                .font("Helvetica")
                .fontSize(11);

            let infoY = orderBoxY + 10;

            doc.text(
                `Order ID: ${receiptData.orderId}`,
                startX + 15,
                infoY
            );

            infoY += 18;

            doc.text(
                `Service Type: ${receiptData.type}`,
                startX + 15,
                infoY
            );

            infoY += 18;

            doc.text(
                `Customer Name: ${receiptData.user.name}`,
                startX + 15,
                infoY
            );

            infoY += 18;

            doc.text(
                `Mobile Number: ${receiptData.user.mobile}`,
                startX + 15,
                infoY
            );

            infoY += 18;

            doc.text(
                `Order Date: ${new Date(
                    receiptData.createdAt
                ).toLocaleString()}`,
                startX + 15,
                infoY
            );

            doc.y = orderBoxY + 110;

            // =====================================================
            // ITEMS TABLE
            // =====================================================

            doc.moveDown(1);

            doc.font("Helvetica-Bold")
                .fontSize(13)
                .text("Items");

            doc.moveDown(0.7);

            const tableTop = doc.y;

            const col = {
                sr: 50,
                item: 110,
                qty: 320,
                price: 390,
                total: 470
            };

            const rowHeight = 28;

            // HEADER ROW
            doc.rect(
                40,
                tableTop,
                pageWidth,
                rowHeight
            )
            .fillAndStroke("#f5f5f5", "#dddddd");

            doc
                .fillColor("black")
                .font("Helvetica-Bold")
                .fontSize(10);

            doc.text("Sr", col.sr, tableTop + 8);
            doc.text("Item", col.item, tableTop + 8);
            doc.text("Qty", col.qty, tableTop + 8);
            doc.text("Price", col.price, tableTop + 8);
            doc.text("Total", col.total, tableTop + 8);

            let currentY = tableTop + rowHeight;

            // ITEMS
            receiptData.items.forEach((item) => {

                doc.rect(
                    40,
                    currentY,
                    pageWidth,
                    rowHeight
                )
                .stroke("#e5e5e5");

                doc
                    .font("Helvetica")
                    .fontSize(10);

                doc.text(
                    item.srNo.toString(),
                    col.sr,
                    currentY + 8
                );

                doc.text(
                    item.name,
                    col.item,
                    currentY + 8,
                    {
                        width: 180
                    }
                );

                doc.text(
                    item.qty.toString(),
                    col.qty,
                    currentY + 8
                );

                doc.text(
                    item.price.toString(),
                    col.price,
                    currentY + 8
                );

                doc.text(
                    item.total.toString(),
                    col.total,
                    currentY + 8
                );

                currentY += rowHeight;
            });

            doc.y = currentY + 20;

            // =====================================================
            // SUMMARY
            // =====================================================

            doc.font("Helvetica-Bold")
                .fontSize(13)
                .text("Payment Summary");

            doc.moveDown(0.5);

            const summaryBoxY = drawBox(100);

            doc
                .font("Helvetica")
                .fontSize(11);

            let summaryY = summaryBoxY + 10;

            doc.text(
                `Total Quantity: ${receiptData.summary.totalQty}`,
                startX + 15,
                summaryY
            );

            summaryY += 20;

            doc.text(
                `Total Amount: ${receiptData.summary.totalAmount}`,
                startX + 15,
                summaryY
            );

            summaryY += 20;

            doc.text(
                `Payment Method: ${receiptData.summary.paymentMethod}`,
                startX + 15,
                summaryY
            );

            summaryY += 20;

            doc.text(
                `Payment Status: ${receiptData.summary.paymentStatus}`,
                startX + 15,
                summaryY
            );

            doc.y = summaryBoxY + 120;

            // =====================================================
            // FOOTER
            // =====================================================

            drawLine();

            doc.moveDown(1);

            doc.fontSize(10)
                .fillColor("gray")
                .text(
                    "Thank you for choosing Washex",
                    {
                        align: "center"
                    }
                );

            doc.end();

            // =====================================================
            // SAVE
            // =====================================================

            stream.on("error", reject);

            stream.on("finish", async () => {

                try {

                    const order =
                        await Order.findByPk(
                            receiptData.orderId
                        );

                    if (!order) {
                        return reject(
                            new Error("Order not found")
                        );
                    }

                    if (!order.receipt_url) {

                        await Order.update(
                            {
                                receipt_url: fileName
                            },
                            {
                                where: {
                                    id: receiptData.orderId
                                }
                            }
                        );
                    }

                    resolve({
                        fileName,
                        filePath
                    });

                } catch (err) {
                    reject(err);
                }
            });

        } catch (error) {
            reject(error);
        }
    });
}

module.exports = generateAndSaveReceipt;